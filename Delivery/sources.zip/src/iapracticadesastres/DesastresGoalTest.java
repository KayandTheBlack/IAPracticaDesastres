package iapracticadesastres;

import aima.search.framework.GoalTest;


public class DesastresGoalTest implements GoalTest {

  public boolean isGoalState(Object aState) {
    return(false);
  }

}
