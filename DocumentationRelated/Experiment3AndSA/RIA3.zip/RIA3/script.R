

> install.packages("latticeExtra")
> library(latticeExtra)


> df<-read.table("ria3test.csv",header=T, sep=";")

> cloud(value~lambda+k, df, panel.3d.cloud=panel.3dbars, col.facet='grey', 
+       xbase=0.4, ybase=0.4, scales=list(arrows=FALSE, col=1), aspect = c(2,1), 
+       par.settings = list(axis.line = list(col = "transparent")))


